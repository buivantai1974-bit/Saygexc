package com.gamebooster.app

/** Cấu hình tối ưu riêng cho từng game. fps = 0, downscale = 100, refreshRate = 0 nghĩa là giữ mặc định. */
data class GameProfile(
    val compileGame: Boolean = true,
    val systemDexopt: Boolean = false,
    val deepCache: Boolean = true,
    val freeRam: Boolean = true,
    val gameMode: Boolean = true,
    val fps: Int = 0,
    val downscale: Int = 100,
    val refreshRate: Int = 0,
    val fastAnimations: Boolean = false,
    val disableBatterySaver: Boolean = true,
    val doNotDisturb: Boolean = false,
    val fixedPerformance: Boolean = false,
    val idleWhitelist: Boolean = true,
    val autoLaunch: Boolean = true
)
