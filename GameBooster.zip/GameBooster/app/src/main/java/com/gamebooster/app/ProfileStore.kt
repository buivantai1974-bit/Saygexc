package com.gamebooster.app

import android.content.Context

/** Lưu game đang chọn và profile của từng game. */
class ProfileStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("gb_profiles", Context.MODE_PRIVATE)

    var selectedGame: String?
        get() = prefs.getString("selected_game", null)
        set(value) {
            prefs.edit().putString("selected_game", value).apply()
        }

    fun load(pkg: String?): GameProfile {
        val d = GameProfile()
        val k = key(pkg)
        return GameProfile(
            compileGame = prefs.getBoolean("$k.compileGame", d.compileGame),
            systemDexopt = prefs.getBoolean("$k.systemDexopt", d.systemDexopt),
            deepCache = prefs.getBoolean("$k.deepCache", d.deepCache),
            freeRam = prefs.getBoolean("$k.freeRam", d.freeRam),
            gameMode = prefs.getBoolean("$k.gameMode", d.gameMode),
            fps = prefs.getInt("$k.fps", d.fps),
            downscale = prefs.getInt("$k.downscale", d.downscale),
            refreshRate = prefs.getInt("$k.refreshRate", d.refreshRate),
            fastAnimations = prefs.getBoolean("$k.fastAnimations", d.fastAnimations),
            disableBatterySaver = prefs.getBoolean("$k.disableBatterySaver", d.disableBatterySaver),
            doNotDisturb = prefs.getBoolean("$k.doNotDisturb", d.doNotDisturb),
            fixedPerformance = prefs.getBoolean("$k.fixedPerformance", d.fixedPerformance),
            idleWhitelist = prefs.getBoolean("$k.idleWhitelist", d.idleWhitelist),
            autoLaunch = prefs.getBoolean("$k.autoLaunch", d.autoLaunch)
        )
    }

    fun save(pkg: String?, p: GameProfile) {
        val k = key(pkg)
        prefs.edit()
            .putBoolean("$k.compileGame", p.compileGame)
            .putBoolean("$k.systemDexopt", p.systemDexopt)
            .putBoolean("$k.deepCache", p.deepCache)
            .putBoolean("$k.freeRam", p.freeRam)
            .putBoolean("$k.gameMode", p.gameMode)
            .putInt("$k.fps", p.fps)
            .putInt("$k.downscale", p.downscale)
            .putInt("$k.refreshRate", p.refreshRate)
            .putBoolean("$k.fastAnimations", p.fastAnimations)
            .putBoolean("$k.disableBatterySaver", p.disableBatterySaver)
            .putBoolean("$k.doNotDisturb", p.doNotDisturb)
            .putBoolean("$k.fixedPerformance", p.fixedPerformance)
            .putBoolean("$k.idleWhitelist", p.idleWhitelist)
            .putBoolean("$k.autoLaunch", p.autoLaunch)
            .apply()
    }

    private fun key(pkg: String?): String = "p." + (pkg ?: "default")
}
