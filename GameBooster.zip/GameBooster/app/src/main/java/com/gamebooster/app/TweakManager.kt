package com.gamebooster.app

import android.content.Context

/**
 * Các tinh chỉnh hệ thống qua Shizuku. Mọi giá trị gốc đều được sao lưu
 * để nút "Khôi phục" đưa máy về như cũ.
 */
class TweakManager(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("gb_backup", Context.MODE_PRIVATE)

    private fun ShizukuShell.Result.ok(): Boolean =
        isSuccess && !output.contains("Exception") && !error.contains("Exception")

    private fun report(name: String, ok: Boolean, log: (String) -> Unit) {
        if (ok) log("✅ $name") else log("⚠️ $name: máy không hỗ trợ hoặc bị chặn")
    }

    private suspend fun readSetting(namespace: String, key: String): String {
        val r = ShizukuShell.exec("settings get $namespace $key")
        val v = r.output.trim()
        return if (r.isSuccess && v.isNotEmpty()) v else "null"
    }

    private suspend fun putSetting(namespace: String, key: String, value: String): Boolean {
        val backupKey = "setting/$namespace/$key"
        if (!prefs.contains(backupKey)) {
            prefs.edit().putString(backupKey, readSetting(namespace, key)).apply()
        }
        return ShizukuShell.exec("settings put $namespace $key $value").isSuccess
    }

    /** Áp dụng toàn bộ tinh chỉnh theo profile. pkg = null nghĩa là chưa chọn game. */
    suspend fun applyAll(pkg: String?, p: GameProfile, log: (String) -> Unit) {
        if (p.disableBatterySaver) {
            report("Tắt chế độ tiết kiệm pin", putSetting("global", "low_power", "0"), log)
        }

        if (p.fastAnimations) {
            var ok = true
            val keys = listOf(
                "window_animation_scale",
                "transition_animation_scale",
                "animator_duration_scale"
            )
            for (k in keys) {
                if (!putSetting("global", k, "0.5")) ok = false
            }
            report("Tăng tốc hoạt ảnh hệ thống (0.5x)", ok, log)
        }

        if (p.refreshRate > 0) {
            val hz = "${p.refreshRate}.0"
            val a = putSetting("system", "min_refresh_rate", hz)
            val b = putSetting("system", "peak_refresh_rate", hz)
            report("Khóa tần số quét ${p.refreshRate}Hz", a && b, log)
        }

        if (p.doNotDisturb) applyDnd(log)
        if (p.fixedPerformance) applyFixedPerformance(log)

        if (pkg != null) {
            if (p.gameMode) applyGameMode(pkg, p.fps, p.downscale, log)
            if (p.idleWhitelist) applyIdleWhitelist(pkg, log)
        } else if (p.gameMode || p.idleWhitelist) {
            log("ℹ️ Chưa chọn game nên bỏ qua Game Mode và miễn tối ưu pin.")
        }
    }

    private suspend fun applyDnd(log: (String) -> Unit) {
        val had = prefs.contains("flag/zen")
        if (!had) {
            prefs.edit().putString("flag/zen", readSetting("global", "zen_mode")).apply()
        }
        val r = ShizukuShell.exec("cmd notification set_dnd priority")
        if (!r.ok() && !had) prefs.edit().remove("flag/zen").apply()
        report("Bật Không làm phiền", r.ok(), log)
    }

    private suspend fun applyFixedPerformance(log: (String) -> Unit) {
        val r = ShizukuShell.exec("cmd power set-fixed-performance-mode-enabled true")
        if (r.ok()) prefs.edit().putString("flag/fixedperf", "1").apply()
        report("Chế độ hiệu năng cố định", r.ok(), log)
    }

    private suspend fun applyGameMode(pkg: String, fps: Int, downscalePct: Int, log: (String) -> Unit) {
        val modeResult = ShizukuShell.exec("cmd game mode performance $pkg")
        report("Game Mode: Performance", modeResult.ok(), log)
        var anyOk = modeResult.ok()

        if (fps > 0 || downscalePct < 100) {
            val sb = StringBuilder("cmd game set --mode performance")
            if (downscalePct < 100) sb.append(" --downscale ").append(downscalePct / 100.0)
            if (fps > 0) sb.append(" --fps ").append(fps)
            sb.append(" ").append(pkg)
            val r = ShizukuShell.exec(sb.toString())
            report("Giới hạn FPS / độ phân giải cho game", r.ok(), log)
            if (r.ok()) anyOk = true
        }

        if (anyOk) prefs.edit().putString("flag/game/$pkg", "1").apply()
    }

    private suspend fun applyIdleWhitelist(pkg: String, log: (String) -> Unit) {
        val list = ShizukuShell.exec("cmd deviceidle whitelist")
        if (list.output.contains(",$pkg,")) {
            log("✅ Game đã được miễn tối ưu pin sẵn")
            return
        }
        val r = ShizukuShell.exec("cmd deviceidle whitelist +$pkg")
        if (r.ok()) prefs.edit().putString("flag/idle/$pkg", "1").apply()
        report("Miễn tối ưu pin (Doze) cho game", r.ok(), log)
    }

    /** Đưa mọi thứ về trạng thái trước khi tối ưu. */
    suspend fun restoreAll(log: (String) -> Unit) {
        val snapshot: Map<String, *> = prefs.all
        if (snapshot.isEmpty()) {
            log("ℹ️ Không có thay đổi nào cần khôi phục.")
            return
        }
        log("↩ Đang khôi phục cài đặt gốc...")
        for ((key, raw) in snapshot) {
            val value = raw?.toString() ?: continue
            val ok: Boolean = when {
                key.startsWith("setting/") -> {
                    val parts = key.removePrefix("setting/").split("/", limit = 2)
                    if (parts.size != 2) {
                        true
                    } else {
                        val cmd = if (value == "null") {
                            "settings delete ${parts[0]} ${parts[1]}"
                        } else {
                            "settings put ${parts[0]} ${parts[1]} '$value'"
                        }
                        ShizukuShell.exec(cmd).isSuccess
                    }
                }
                key == "flag/zen" -> {
                    val mode = when (value) {
                        "1" -> "priority"
                        "2" -> "none"
                        "3" -> "alarms"
                        else -> "off"
                    }
                    ShizukuShell.exec("cmd notification set_dnd $mode").isSuccess
                }
                key == "flag/fixedperf" ->
                    ShizukuShell.exec("cmd power set-fixed-performance-mode-enabled false").isSuccess
                key.startsWith("flag/game/") -> {
                    val pkg = key.removePrefix("flag/game/")
                    val a = ShizukuShell.exec("cmd game reset $pkg").isSuccess
                    val b = ShizukuShell.exec("cmd game mode standard $pkg").isSuccess
                    a || b
                }
                key.startsWith("flag/idle/") -> {
                    val pkg = key.removePrefix("flag/idle/")
                    ShizukuShell.exec("cmd deviceidle whitelist -$pkg").isSuccess
                }
                else -> true
            }
            if (ok) {
                prefs.edit().remove(key).apply()
            } else {
                log("⚠️ Không khôi phục được: $key")
            }
        }
        log("✅ Đã khôi phục xong.")
    }
}
