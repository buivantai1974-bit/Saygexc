package com.gamebooster.app

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_CODE_SHIZUKU = 1001
        private const val OPTIMIZE_LABEL = "🚀 Tối Ưu Hóa & Vào Game"
    }

    private data class AppEntry(val label: String, val pkg: String, val isGame: Boolean)

    private val fpsValues = intArrayOf(0, 30, 45, 60, 90, 120)
    private val fpsLabels = listOf("Mặc định", "30 FPS", "45 FPS", "60 FPS", "90 FPS", "120 FPS")
    private val downscaleValues = intArrayOf(100, 90, 80, 70, 60, 50)
    private val downscaleLabels = listOf("Mặc định (100%)", "90%", "80%", "70%", "60%", "50%")
    private val refreshValues = intArrayOf(0, 60, 90, 120, 144)
    private val refreshLabels = listOf("Mặc định", "60 Hz", "90 Hz", "120 Hz", "144 Hz")
    private val presetLabels = listOf("Tùy chỉnh", "Cân bằng", "Hiệu năng cao", "Tối đa")

    private lateinit var store: ProfileStore
    private lateinit var tweaks: TweakManager

    private lateinit var tvStatus: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvGame: TextView
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var btnPickGame: Button
    private lateinit var btnOptimize: Button
    private lateinit var btnRestore: Button

    private lateinit var spPreset: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spDownscale: Spinner
    private lateinit var spRefresh: Spinner

    private lateinit var swCompileGame: SwitchCompat
    private lateinit var swSystemDexopt: SwitchCompat
    private lateinit var swDeepCache: SwitchCompat
    private lateinit var swFreeRam: SwitchCompat
    private lateinit var swGameMode: SwitchCompat
    private lateinit var swAnimations: SwitchCompat
    private lateinit var swBatterySaver: SwitchCompat
    private lateinit var swDnd: SwitchCompat
    private lateinit var swFixedPerf: SwitchCompat
    private lateinit var swIdle: SwitchCompat
    private lateinit var swAutoLaunch: SwitchCompat

    private var isRunning = false
    private var binding = false
    private var currentPkg: String? = null
    private var currentProfile = GameProfile()

    // --- Listeners vòng đời Shizuku ---
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread {
            appendLog("Shizuku đã chạy (binder nhận được).")
            updateStatus()
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            appendLog("Shizuku đã dừng (binder mất kết nối).")
            updateStatus()
        }
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode != REQUEST_CODE_SHIZUKU) return@OnRequestPermissionResultListener
            runOnUiThread {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    appendLog("✅ Đã được cấp quyền Shizuku.")
                    Toast.makeText(this, "Đã cấp quyền Shizuku", Toast.LENGTH_SHORT).show()
                } else {
                    appendLog("❌ Quyền Shizuku bị từ chối.")
                    Toast.makeText(this, "Quyền Shizuku bị từ chối", Toast.LENGTH_SHORT).show()
                }
                updateStatus()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = ProfileStore(this)
        tweaks = TweakManager(this)

        bindViews()
        setupSpinners()
        setupListeners()

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        val saved = store.selectedGame
        val savedLabel = if (saved != null) labelOf(saved) else null
        if (saved != null && savedLabel != null) {
            currentPkg = saved
            tvGame.text = "🎮 $savedLabel"
        } else {
            currentPkg = null
            tvGame.text = "Chưa chọn game (áp dụng chung)"
        }
        bindProfile(store.load(currentPkg))

        appendLog("Chào mừng! Hãy bật Shizuku, chọn game rồi bấm nút tối ưu.")
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        refreshRam()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }

    // --- Khởi tạo giao diện ---

    private fun bindViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvRam = findViewById(R.id.tvRam)
        tvGame = findViewById(R.id.tvGame)
        tvLog = findViewById(R.id.tvLog)
        scrollLog = findViewById(R.id.scrollLog)
        btnPickGame = findViewById(R.id.btnPickGame)
        btnOptimize = findViewById(R.id.btnOptimize)
        btnRestore = findViewById(R.id.btnRestore)

        spPreset = findViewById(R.id.spPreset)
        spFps = findViewById(R.id.spFps)
        spDownscale = findViewById(R.id.spDownscale)
        spRefresh = findViewById(R.id.spRefresh)

        swCompileGame = findViewById(R.id.swCompileGame)
        swSystemDexopt = findViewById(R.id.swSystemDexopt)
        swDeepCache = findViewById(R.id.swDeepCache)
        swFreeRam = findViewById(R.id.swFreeRam)
        swGameMode = findViewById(R.id.swGameMode)
        swAnimations = findViewById(R.id.swAnimations)
        swBatterySaver = findViewById(R.id.swBatterySaver)
        swDnd = findViewById(R.id.swDnd)
        swFixedPerf = findViewById(R.id.swFixedPerf)
        swIdle = findViewById(R.id.swIdle)
        swAutoLaunch = findViewById(R.id.swAutoLaunch)
    }

    private fun setupSpinner(sp: Spinner, labels: List<String>) {
        val adapter = ArrayAdapter(this, R.layout.spinner_item, labels)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        sp.adapter = adapter
    }

    private fun setupSpinners() {
        setupSpinner(spPreset, presetLabels)
        setupSpinner(spFps, fpsLabels)
        setupSpinner(spDownscale, downscaleLabels)
        setupSpinner(spRefresh, refreshLabels)
    }

    private fun setupListeners() {
        btnPickGame.setOnClickListener { showGamePicker() }
        btnOptimize.setOnClickListener { onOptimizeClicked() }
        btnRestore.setOnClickListener { onRestoreClicked() }

        val switches = listOf(
            swCompileGame, swSystemDexopt, swDeepCache, swFreeRam, swGameMode,
            swAnimations, swBatterySaver, swDnd, swFixedPerf, swIdle, swAutoLaunch
        )
        for (sw in switches) {
            sw.setOnCheckedChangeListener { _, _ -> onControlChanged() }
        }

        val spinners = listOf(spFps, spDownscale, spRefresh)
        for (sp in spinners) {
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    onControlChanged()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }
        }

        spPreset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (binding || position == 0) return
                applyPreset(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    // --- Profile <-> giao diện ---

    private fun indexOfValue(values: IntArray, v: Int): Int {
        val i = values.indexOf(v)
        return if (i >= 0) i else 0
    }

    private fun bindProfile(p: GameProfile) {
        binding = true
        currentProfile = p
        swCompileGame.isChecked = p.compileGame
        swSystemDexopt.isChecked = p.systemDexopt
        swDeepCache.isChecked = p.deepCache
        swFreeRam.isChecked = p.freeRam
        swGameMode.isChecked = p.gameMode
        swAnimations.isChecked = p.fastAnimations
        swBatterySaver.isChecked = p.disableBatterySaver
        swDnd.isChecked = p.doNotDisturb
        swFixedPerf.isChecked = p.fixedPerformance
        swIdle.isChecked = p.idleWhitelist
        swAutoLaunch.isChecked = p.autoLaunch
        spFps.setSelection(indexOfValue(fpsValues, p.fps))
        spDownscale.setSelection(indexOfValue(downscaleValues, p.downscale))
        spRefresh.setSelection(indexOfValue(refreshValues, p.refreshRate))
        binding = false
    }

    private fun readProfileFromUi(): GameProfile {
        return GameProfile(
            compileGame = swCompileGame.isChecked,
            systemDexopt = swSystemDexopt.isChecked,
            deepCache = swDeepCache.isChecked,
            freeRam = swFreeRam.isChecked,
            gameMode = swGameMode.isChecked,
            fps = fpsValues[spFps.selectedItemPosition.coerceAtLeast(0)],
            downscale = downscaleValues[spDownscale.selectedItemPosition.coerceAtLeast(0)],
            refreshRate = refreshValues[spRefresh.selectedItemPosition.coerceAtLeast(0)],
            fastAnimations = swAnimations.isChecked,
            disableBatterySaver = swBatterySaver.isChecked,
            doNotDisturb = swDnd.isChecked,
            fixedPerformance = swFixedPerf.isChecked,
            idleWhitelist = swIdle.isChecked,
            autoLaunch = swAutoLaunch.isChecked
        )
    }

    private fun onControlChanged() {
        if (binding) return
        val p = readProfileFromUi()
        if (p == currentProfile) return
        currentProfile = p
        store.save(currentPkg, p)
        if (spPreset.selectedItemPosition != 0) {
            binding = true
            spPreset.setSelection(0)
            binding = false
        }
    }

    private fun presetProfile(index: Int): GameProfile {
        return when (index) {
            1 -> GameProfile()
            2 -> GameProfile().copy(
                fastAnimations = true,
                fixedPerformance = true
            )
            3 -> GameProfile().copy(
                systemDexopt = true,
                fps = 120,
                downscale = 80,
                refreshRate = 120,
                fastAnimations = true,
                doNotDisturb = true,
                fixedPerformance = true
            )
            else -> currentProfile
        }
    }

    private fun applyPreset(index: Int) {
        val p = presetProfile(index)
        bindProfile(p)
        store.save(currentPkg, p)
        appendLog("Đã áp dụng mức \"${presetLabels[index]}\".")
    }

    // --- Chọn game ---

    private fun labelOf(pkg: String): String? {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun loadLaunchableApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = packageManager.queryIntentActivities(intent, 0)
        return infos
            .map { ri ->
                AppEntry(
                    ri.loadLabel(packageManager).toString(),
                    ri.activityInfo.packageName,
                    ri.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME
                )
            }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedWith(compareBy<AppEntry>({ !it.isGame }, { it.label.lowercase() }))
    }

    private fun showGamePicker() {
        val apps = loadLaunchableApps()
        if (apps.isEmpty()) {
            Toast.makeText(this, "Không tìm thấy ứng dụng nào", Toast.LENGTH_SHORT).show()
            return
        }
        val names = apps.map { (if (it.isGame) "🎮 " else "") + it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Chọn game")
            .setItems(names) { _, which -> selectGame(apps[which]) }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun selectGame(entry: AppEntry) {
        currentPkg = entry.pkg
        store.selectedGame = entry.pkg
        tvGame.text = "🎮 ${entry.label}"
        bindProfile(store.load(entry.pkg))
        binding = true
        spPreset.setSelection(0)
        binding = false
        appendLog("Đã chọn game: ${entry.label} (${entry.pkg}). Profile riêng đã được tải.")
    }

    // --- Quản lý quyền ---

    private fun isShizukuRunning(): Boolean = Shizuku.pingBinder()

    private fun hasShizukuPermission(): Boolean {
        return try {
            isShizukuRunning() &&
                !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.isPreV11()) {
                Toast.makeText(this, "Phiên bản Shizuku quá cũ, hãy cập nhật.", Toast.LENGTH_LONG).show()
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                appendLog("⚠️ Bạn đã chọn \"Từ chối và không hỏi lại\". Hãy cấp quyền trong app Shizuku.")
                Toast.makeText(this, "Hãy cấp quyền trong ứng dụng Shizuku", Toast.LENGTH_LONG).show()
                return
            }
            appendLog("Đang yêu cầu quyền Shizuku...")
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        } catch (e: Exception) {
            appendLog("❌ Lỗi khi xin quyền: ${e.message}")
        }
    }

    private fun requireShizuku(): Boolean {
        if (!isShizukuRunning()) {
            appendLog("❌ Shizuku chưa chạy. Hãy mở app Shizuku và khởi động dịch vụ.")
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show()
            updateStatus()
            return false
        }
        if (!hasShizukuPermission()) {
            requestShizukuPermission()
            return false
        }
        return true
    }

    private fun updateStatus() {
        val running = isShizukuRunning()
        val granted = hasShizukuPermission()
        when {
            running && granted -> {
                tvStatus.text = "● Đã kết nối"
                tvStatus.setTextColor(Color.parseColor("#00FF9C"))
            }
            running -> {
                tvStatus.text = "● Chưa kết nối (chưa cấp quyền)"
                tvStatus.setTextColor(Color.parseColor("#FFB800"))
            }
            else -> {
                tvStatus.text = "● Chưa kết nối (Shizuku chưa chạy)"
                tvStatus.setTextColor(Color.parseColor("#FF3B5C"))
            }
        }
    }

    // --- Nút bấm ---

    private fun setBusy(busy: Boolean, text: String = OPTIMIZE_LABEL) {
        isRunning = busy
        btnOptimize.isEnabled = !busy
        btnRestore.isEnabled = !busy
        btnPickGame.isEnabled = !busy
        btnOptimize.text = if (busy) text else OPTIMIZE_LABEL
    }

    private fun onOptimizeClicked() {
        if (isRunning) return
        if (!requireShizuku()) return

        val profile = readProfileFromUi()
        val pkg = currentPkg
        setBusy(true, "⏳ Đang tối ưu...")

        lifecycleScope.launch {
            try {
                Optimizer.runProfile(tweaks, pkg, profile) { msg -> appendLog(msg) }
                refreshRam()
                if (profile.autoLaunch && pkg != null) launchGame(pkg)
            } catch (e: Exception) {
                appendLog("❌ Lỗi không mong muốn: ${e.message}")
            } finally {
                setBusy(false)
            }
        }
    }

    private fun onRestoreClicked() {
        if (isRunning) return
        if (!requireShizuku()) return

        setBusy(true, "⏳ Đang khôi phục...")
        lifecycleScope.launch {
            try {
                tweaks.restoreAll { msg -> appendLog(msg) }
            } catch (e: Exception) {
                appendLog("❌ Lỗi khi khôi phục: ${e.message}")
            } finally {
                setBusy(false)
            }
        }
    }

    private fun launchGame(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appendLog("🎮 Đang mở game...")
            startActivity(intent)
        } else {
            appendLog("⚠️ Không mở được game, hãy mở thủ công.")
        }
    }

    private fun refreshRam() {
        lifecycleScope.launch {
            val mb = Optimizer.readAvailableMemMb()
            tvRam.text = if (mb >= 0) "RAM trống: $mb MB" else "RAM trống: không đọc được"
        }
    }

    // --- Log ---

    private fun appendLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        tvLog.append("[$time] $message\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
